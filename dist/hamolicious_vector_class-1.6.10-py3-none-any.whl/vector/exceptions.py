

class DimensionsMismatch(Exception):
	pass




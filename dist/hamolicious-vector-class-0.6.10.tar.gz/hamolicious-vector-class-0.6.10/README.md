![is_maintained](https://camo.githubusercontent.com/6e4da91cb02711349e6b9d0aba6a767362818c1d17891a02f06fded4415f6172/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4d61696e7461696e65642533462d7965732d677265656e2e737667)
![pypi_version](https://img.shields.io/badge/pypi-v1.6.10-%233775A9)

# Vector-Class
Had a realisation that I lack a good vector class and been having to rewrite parts of it every now and then, so I wrote a simple Vector Class for 2D and 3D Vectors.

To use this class, simply download the vector file and import it into your project, alternatively, copy and paste the code from the vector file and paste it into your own file. This class will work with the most basic version of python, meaning, no need for external libraries :)
<br>
[Documentation here](https://github.com/hamolicious/Vector-Class/wiki)
<br>

## Things I still want to add:
* Matrix support
